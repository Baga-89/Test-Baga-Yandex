package com.justai.model_api_demo.dto.preprocessor

data class ScriptDoc (
    val text:String,
    val corrected:String
)