package com.justai.model_api_demo.dto.preprocessor

data class TextPreprocessorResponseData (
        val result:List<MarkupData>
)