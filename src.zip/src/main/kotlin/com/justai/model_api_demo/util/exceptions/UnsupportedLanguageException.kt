package com.justai.model_api_demo.util.exceptions

class UnsupportedLanguageException(name: String) : Exception("Language $name is not supported.")